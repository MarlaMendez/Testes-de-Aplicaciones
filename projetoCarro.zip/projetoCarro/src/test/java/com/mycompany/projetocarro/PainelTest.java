
package com.mycompany.projetocarro;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.Duration;
import org.junit.jupiter.api.Timeout;

/**
 *
 * @author Marla
 */
public class PainelTest {
    Painel painel;
    Sistema_direcao sisdirecao;
    Sistema_eletrico siseletrico;
    Sistema_transmisao sistransmisao;
    Sistema_combustivel siscombustivel;
    Freios freios;
    Luzes luzes;
    Timeout tiempo;
    
    
    public PainelTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
  
        sisdirecao = new Sistema_direcao();
        siseletrico = new Sistema_eletrico();
        sistransmisao = new Sistema_transmisao();
        siscombustivel = new Sistema_combustivel();
        freios = new Freios ();
        luzes = new Luzes();
        painel = new Painel ();
        
        painel.sisdirecao = sisdirecao;
        painel.siseletrico = siseletrico;
        painel.sistransmisao = sistransmisao;
        painel.siscombustivel = siscombustivel;
        painel.freios = freios;
        painel.luzes = luzes;
        
        
        
    }
    
    @AfterEach
    public void tearDown() {
    }

  //ARREGLAR ESTO
    @Test
    public void muestrainfoPainelTest() {
        assertTimeout(Duration.ofSeconds(3), () -> {
        System.out.println("Dando valores");
        sisdirecao.setAngulo(30.0);
        siseletrico.setVoltagem(50.0);
        sistransmisao.setMarcha_actual(5);
        siscombustivel.setNivelCombustivel(100.0);
        
        double angulo = sisdirecao.getAngulo();
        double voltagem = siseletrico.getVoltagem();
        int marcha = sistransmisao.getMarcha_actual();
        double combustivel = siscombustivel.getNivelCombustivel();
        
        
        System.out.println("Informacion obtenida de angulo, voltagem, marcha y combustible: "+angulo+voltagem+marcha+combustivel);
        
        
        
        painel.infoDirecao(sisdirecao);
        painel.infoEletrico(siseletrico);
        painel.infoTransmisao(sistransmisao);
        painel.infoGasolina(siscombustivel);
        
        String display = painel.getDisplay();
        
        painel.atualizarInformacao(display);
        
        
    });
                
    }


   
    @Test
    public void testInfoFreios() {
        System.out.println("infoFreios");
        Freios freios = null;
        Painel instance = new Painel();
        instance.infoFreios(freios);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   
    @Test
    public void testInfoLuz() {
        System.out.println("infoLuz");
        Luzes luzes = null;
        Painel instance = new Painel();
        instance.infoLuz(luzes);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
   

    
}
