package com.mycompany.projetocarro;

public class Painel {

    String tipo;
    String display;
    boolean controle;
    String marca;
    boolean estado;
    Motor motor;
    Pneus pneus;

    Sistema_eletrico siseletrico = new Sistema_eletrico (100.00, 2000.00, "Novex", "Eletrolux", true );
    Sistema_direcao sisdirecao = new Sistema_direcao("Assistido", true, "Metal", 55.00, "Otimox", 90.00, siseletrico);
    Sistema_transmisao sistransmisao = new Sistema_transmisao("Manual e automatica", 5, "Metal", "Lux", 0, motor);
    Sistema_combustivel siscombustivel = new Sistema_combustivel ("Diesel", 500.00, 20, "Petrobas", true);
    Suspensao suspensao = new Suspensao ("Multilink", "Ferro", 10.00, 10, "Petrobaz", 45, true);
    Freios freios = new Freios("Tambor", "Ferro", 20.00, "Durex", 1.00, pneus);
    Luzes luzes = new Luzes("Led", 1, "Branca", "Redonda", siseletrico);

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDisplay() {
        return display;
    }

    public void setDisplay(String display) {
        this.display = display;
    }

    public boolean isControle() {
        return controle;
    }

    public void setControle(boolean controle) {
        this.controle = controle;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isEstado() {
        return this.estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public void ligarDisplay() {
        boolean estadoEletrico = siseletrico.isEstado();
        
        if ( estadoEletrico == true) {
             this.estado = true;
             System.out.println("O display està ligado");
        } else { 
            System.out.println("Não foi possivel ligar o painel, sisteme eletrico desligado!");
        }
       
        
    }

    public void desligarDisplay() {
        this.estado = false;
        System.out.println("O display està desligado");
    }

    public void atualizarInformacao(String info) {
        this.display = info;
        System.out.println("Painel- " + info);
    }

    
    // ----------------------------------------------------------
    
    // METODOS DE INTEGRACION
    
    
    
    // muestra informacion en el painel/display
    public void infoDirecao() {
        String info = "Angulo de direção: " + sisdirecao.getAngulo();
        atualizarInformacao(info);

    }

    public void infoEletrico() {
        String info = "Informacion de voltagem: " + siseletrico.getVoltagem();
        atualizarInformacao(info);
    }

    public void infoTransmisao() {
        String info = "Marcha actual: " + sistransmisao.getMarcha_actual();
        atualizarInformacao(info);

    }

    public void infoGasolina() {
        String info = "Nivel de gasolina " + siscombustivel.getNivelCombustivel();
        atualizarInformacao(info);
    }
    
    public void infoSuspensao () {
        String info = "Estado da suspensao " + suspensao.isEstadoSuspensao(); 
        atualizarInformacao(info);
                
    }
    

    
    //----------------------------------------------------------------
    
    // freios y sistema eletrico, Painel
    public void verificarFreios() {
        
        boolean estadoPainel = isEstado();
        
        if (estadoPainel == true) {
            ligarDisplay();
            System.out.println("Painel/Display ligado");
        } else {
            System.out.println("Painel desligado");
        }
        
        double desgaste = freios.getNivelDesgaste();

        if (desgaste > 2) {
            atualizarInformacao("Verificar desgaste de freios");
            freios.verificarDesgaste();
            

        } else {
            System.out.println("Freios funcionando correctamente");
        }
    }

    //------------------------------------------------------
    
    
    
    
    public void infoLuz(Luzes luzes) {
        int intensidade = luzes.getIntensidade();
        boolean estadoEletrico = siseletrico.isEstado();
        double valorVoltagem = siseletrico.getVoltagem();

        if (estadoEletrico == true && valorVoltagem > 0) {
            luzes.ligar();

            if (intensidade < 10) {
                atualizarInformacao("La intensidad es fraca! ajuste!");
                siseletrico.recargarBateria(200);
                luzes.ajustarIntensidade(60);
            } else {
                System.out.println("Intensidade boa");

            }

        } else {
            System.out.println("Sistema eletrico apagado o sin voltagem suficiente");
        }
    }
}
