package com.mycompany.projetocarro;

public class Sistema_direcao {

    String tipo;
    boolean assistido;
    String material;
    double relacao;
    String marca;
    double angulo;
    boolean bocina;
    boolean volanteIzq;
    
    Sistema_eletrico siseletrico;

    
    public Sistema_direcao(String tipo, boolean assistido, String material, double relacao, String marca, double angulo, Sistema_eletrico siseletrico) {
        this.tipo = tipo;
        this.assistido = assistido;
        this.material = material;
        this.relacao = relacao;
        this.marca = marca;
        this.angulo = angulo;
        this.siseletrico = siseletrico;
    }

    public boolean isVolanteIzq() {
        return volanteIzq;
    }

    public void setVolanteIzq(boolean volanteIzq) {
        this.volanteIzq = volanteIzq;
    }

    
    public boolean isBocina() {
        return bocina;
    }

    public void setBocina(boolean bocina) {
        this.bocina = bocina;
    }

    
    
    public double getAngulo() {
        return angulo;
    }

    public void setAngulo(double angulo) {
        this.angulo = angulo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isAssistido() {
        return assistido;
    }

    public void setAssistido(boolean assistido) {
        this.assistido = assistido;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getRelacao() {
        return relacao;
    }

    public void setRelacao(double relacao) {
        this.relacao = relacao;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    // ----------------------------------------------
    public void ligarAssistido() {
        boolean estadoEletrico = siseletrico.isEstado();

        if (estadoEletrico == true) {
            this.assistido = true;
            System.out.println("Assistido ligado");
        } else {
            System.out.println("Não foi possivel ligar modo assistido, verificar sistema eletrico");
        }

    }

    public void desligarAssistido() {
        this.assistido = false;
    }

    public void apertarBocina() {
        System.out.println("fooon fooon");
        this.bocina = true;
    }

    public void bocinaVolante() {
        boolean estadoEletrico = siseletrico.isEstado();

        if (estadoEletrico == true) {
            apertarBocina();

        } else {
            System.out.println("Não foi possivel apertar a bocina, verifica sistema eletrico!");
        }

    }

    public void girarVolanteIzquierda() {
        boolean estadoAssistido = isAssistido();
        double valorAngulo = getAngulo();

        if (estadoAssistido == true && valorAngulo <= 50) {
            this.volanteIzq = true;
            System.out.println("Girando volante para a izquierda");
        
        } 
    }

}
