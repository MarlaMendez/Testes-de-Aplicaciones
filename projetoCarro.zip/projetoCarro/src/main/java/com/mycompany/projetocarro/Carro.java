
package com.mycompany.projetocarro;

public class Carro {
    String modelo;
    int ano;
    String cor;
    String placa;
    double quilometragem;
    Porta puerta = new Porta ();
    Sistema_Combustivel gasolina = new Sistema_Combustivel ( );
    Motor motor = new Motor ();

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getQuilometragem() {
        return quilometragem;
    }

    public void setQuilometragem(double quilometragem) {
        this.quilometragem = quilometragem;
    }
    
    
    
    
    public void ligar () {
        System.out.println("Carro ligado");
    }
    public void desligar () {
        System.out.println("Carro desligado");
    }
    public void actualizarQuilometragem (double km) {
        System.out.println("Kilometragem nova "+quilometragem);
    }
    
    public void estadoPorta (){
        puerta.verificarEstado();
    }
    
    public void verificarGasolina () {
        gasolina.verificarNivel();
        double gasoide = gasolina.getNivelCombustivel();
        
        if (gasoide > 0) {
            motor.ligar();
            
        } else {
            gasolina.abastecer(gasoide);
            motor.ligar();
        }
        
    }
    
}
