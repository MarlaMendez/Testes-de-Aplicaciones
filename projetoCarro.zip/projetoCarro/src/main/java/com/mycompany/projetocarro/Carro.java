
package com.mycompany.projetocarro;

public class Carro {
   
    String modelo;
    int ano;
    String cor;
    String placa;
    double quilometragem;
    
    Sistema_combustivel siscombustivel = new Sistema_combustivel ();
    Sistema_eletrico siseletrico = new Sistema_eletrico ();
    
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getQuilometragem() {
        return quilometragem;
    }
    

    public void setQuilometragem(double quilometragem) {
        this.quilometragem = quilometragem;
    }
    
    public void mostrarInfo(String modelo, int ano, String cor, String placa ){
        this.modelo = modelo;
        this.ano = ano;
        this.cor = cor;
        this.placa = placa;
        
        System.out.println("Informação do carro: "+modelo +ano+cor+placa);
        
    }
    public void ligar () {
        System.out.println("Carro ligado");
    }
    public void desligar () {
        System.out.println("Carro desligado");
    }
    public void actualizarQuilometragem (double km) {
        System.out.println("Kilometragem nova "+quilometragem);
    }
  
    public void estadoElementos () {
       double gasolinaActual;
       double voltagemActual;
       
       gasolinaActual = siscombustivel.getNivelCombustivel();
       voltagemActual = siseletrico.getVoltagem();
       
       
       if (gasolinaActual > 10 && voltagemActual > 10) {
           ligar();
       } else {
           System.out.println("Nivel de gasolina e voltagem  insuficiente, porfavor abastecer!");
           siscombustivel.abastecer(100);
           siseletrico.substituirBateria();
           ligar();
       }
   }
    
    
    public static void main(String[] args) {
        Carro carro = new Carro () ;
        Painel painel = new Painel ();
        Sistema_direcao sisdirecao = new Sistema_direcao ();
        Sistema_combustivel siscombustivel = new Sistema_combustivel ();
        Sistema_eletrico siseletrico = new Sistema_eletrico ();
        
        //Llamando metodo que muestra informacion del carro
        carro.mostrarInfo(" Ferrari ", 2016, " amarillo ", " 1233456 ");
        siscombustivel.setNivelCombustivel(15);
        siseletrico.setVoltagem(15);
        
        
        sisdirecao.ajustarDirecao(50);
        painel.infoDirecao(sisdirecao);
        siscombustivel.verificarNivel(20);
        painel.infoGasolina(siscombustivel);
        siseletrico.verificarBateria(16.7);
        painel.infoEletrico(siseletrico);
       
        carro.estadoElementos();
        
        
        
    }
 
    
}
