
package com.mycompany.projetocarro;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;



public class CarroTest {
    Carro carro;
    Sistema_combustivel siscumbustivel;
    Sistema_eletrico siseletrico;
    Porta porta;
    Bancos bancos;
    Pneus pneus;
    Suspensao suspensao;
    Motor motor;
    Painel painel;
    Sistema_direcao sisdirecao;
    
    public CarroTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
     siscumbustivel = new Sistema_combustivel ("Diesel", 500.00, 20.00, "Petrobas", true);
     siseletrico = new Sistema_eletrico (100.00, 2000.00, "Novex", false, "Eletrolux" );
     porta = new Porta (4, "Metal", "Branco", "Forte", "Fechada");
     carro = new Carro ("K12", 2010, "Branco", "AB-1234", 150.00, false);
     bancos = new Bancos ();
     pneus = new Pneus ();
     suspensao = new Suspensao ();
     motor = new Motor("Jato", 5, 45.00, "Hercules", false);
     painel = new Painel();
     sisdirecao = new Sistema_direcao();
     
     carro.siscombustivel = siscumbustivel;
     carro.siseletrico = siseletrico;
     carro.porta = porta;
     carro.bancos = bancos;
     suspensao.pneus = pneus;
     suspensao.motor = motor;
     suspensao.sisdirecao = sisdirecao;
     carro.suspensao = suspensao;
     carro.painel = painel;
     
     
     
        
    }
    
    @AfterEach
    public void tearDown() {
    }

    //------------------------------------------------------------------
    
    //ESTA CORRECTO
    //Claes usadas: carro, sistema eletrico, sistema de combustivel y motor.
    @Test
    public void estadoCombustivelYVoltagemYMotorTest() {
        System.out.println("Test motor, sistema eletrico y sistema de combustible");
        double combustible = siscumbustivel.getNivelCombustivel();
        double voltagem = siseletrico.getVoltagem();
        boolean estadoMotor = motor.isEstado();
        double quilometragemNova = carro.getQuilometragem();
        
        System.out.println("Combustible: "+combustible+ " Voltagem: "+voltagem+ "Motor: "+estadoMotor+ "Quilometragem: "+quilometragemNova);
       
        carro.estadoElementos();
        
        //Usando AssertEquals
        assertEquals(20.0, siscumbustivel.getNivelCombustivel());
        assertEquals(100.0, siseletrico.getVoltagem());
        assertEquals(151.0, carro.getQuilometragem());
        assertTrue(carro.motor.isEstado());
    }
    
    //------------------------------------------------------------------------

   
    @Test
    //ESTA CORRECTO
    //Clases usadas: carro, porta, motor y sistema eletrico.
    public void verificarportasTest() {
        System.out.println("Test porta, motor e sistema eletrico");
        String puerta = porta.getEstado();
        boolean estadoMotor = motor.isEstado();
        boolean estadoEletrico = siseletrico.isEstado();
        
        System.out.println("El estado de la puerta es: "+puerta+ " El estado del motor es: "+ estadoMotor + " El estado del sistema eletrico es: "+estadoEletrico);
       
        carro.verificarPortas();
        
        
        //Usando assertEquals y AssertTrue
        assertEquals("Fechada", porta.getEstado());
        assertTrue(carro.estaLigado());
        assertTrue(carro.motor.isEstado());
        assertTrue(carro.porta.isJanela());
    }
    
    //--------------------------------------------------------------------------
    
    //clases usadas: carro, bancos y motor
    //assert utilizado: assertEquals
    @Test
    public void bancosTest (){
        carro.bancoAjustado();
        assertEquals(100, bancos.getNovaAltura());
        assertEquals("Adelante", bancos.getPosicao());
        assertTrue(carro.motor.isEstado());
    }
    
    //-------------------------------------------------------------------------
    
    
    //Clases usadas en la integracion: carro, suspensao, pneus, motor y sistema de direccion
    //aserts utilizados: assertTrue.
    @Test
    public void pneusysuspensaoTest () {
        pneus.setDesgaste(20);
        sisdirecao.setAngulo(35);
        
        System.out.println("El nivel de desgaste de las ruedas es : " +pneus.getDesgaste());
        System.out.println("El angulo del sistema de direcion es: : " +sisdirecao.getAngulo());
        
        carro.verificarPneusSuspensao();
        
        assertTrue(motor.isEstado());   
        assertTrue(sisdirecao.ComponenteFueSubstituido());
    }
    
    //---------------------------------------------------------------------------
    
    //classe usada: carro
    //assert usado: assertLinesMatch
    @Test
    public void caracteristicasCarro (){
        carro.mostrarCaracteristicasCarro("Chevrolet", 1990, "Vermelho", "CD-12345");
        List<String> caracEsperada = List.of("Informação do carro: Chevrolet 1990 Vermelho CD-12345");
        assertLinesMatch(caracEsperada, carro.getCaracteristicas());
    }

}
