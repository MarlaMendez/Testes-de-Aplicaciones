
package com.mycompany.projetocarro;


public class Pneus {
    String tamanho;
    String tipo;
    double pressao;
    String marca;
    String estado;
    int desgaste;

    public int getDesgaste() {
        return desgaste;
    }

    public void setDesgaste(int desgaste) {
        this.desgaste = desgaste;
    }
    
    

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPressao() {
        return pressao;
    }

    public void setPressao(double pressao) {
        this.pressao = pressao;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
    
    
public void verificarDesgaste (int desgaste) {
    this.desgaste = desgaste;
        
    }
    
    
public void ajustarPressao (double novaPressao){
    System.out.println("Pressao de pneus ajustado");
    
}

public void substituir () {
    System.out.println("Pneu substituido");
    
}


    
}
