
package com.mycompany.projetocarro;


public class Sistema_transmisao {
    String tipo;
    int numeroDeMarchas;
    String material;
    String marca;
    boolean estado = false;
    int marcha_actual;
    Motor motor;
    
    

    public Sistema_transmisao(String tipo, int numeroDeMarchas, String material, String marca, int marcha_actual, Motor motor) {
        this.tipo = tipo;
        this.numeroDeMarchas = numeroDeMarchas;
        this.material = material;
        this.marca = marca;
        this.marcha_actual = marcha_actual;
        this.motor = motor;
    }
 
    
    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getNumeroDeMarchas() {
        return numeroDeMarchas;
    }

    public void setNumeroDeMarchas(int numeroDeMarchas) {
        this.numeroDeMarchas = numeroDeMarchas;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getMarcha_actual() {
        return marcha_actual;
    }

    public void setMarcha_actual(int marcha_actual) {
        this.marcha_actual = marcha_actual;
    }
    
    
    
    
   
    public void trocarMarcha (int marcha) {
        boolean estadoPedalEmbriague = motor.isEstadoEmbriague();
        boolean estadoTransmisao = isEstado();
        
        if ( estadoPedalEmbriague == true && estadoTransmisao == true ){
            this.marcha_actual = marcha;
            System.out.println("Marcha trocada com sucesso");
        } else {
            System.out.println("Não é possivel trocar a marcha, solte primeiro o pedal e depois troque");
        }
    }
    
   public void ligarTransmisao () { //acto de poder usar a transmissao
       boolean estadoMotor = motor.isEstado();
       
       if (estadoMotor == true) {
           this.estado = true;
           System.out.println("Sistema de transmisao correcto e pronto para ser usado");
       } else {
           System.out.println("Não é possivel mexer na transmissao, ligue o motor");
       }
               
       
   }
   
   public void desligarTransmisao () {
       this.estado = false;
       System.out.println("Tranmissao desligada");
   }
    
}
