
package com.mycompany.projetocarro;


public class Porta {
    int quantidade;
    String material;
    String cor;
    String tipo;
    String estado;
    boolean janela;
    
    Sistema_eletrico siseletrico = new Sistema_eletrico (100.00, 2000.00, "Novex", false, "Eletrolux" );

    public boolean isJanela() {
        return janela;
    }

    public void setJanela(boolean janela) {
        this.janela = janela;
    }
    
    

    public Porta(int quantidade, String material, String cor, String tipo, String estado) {
        this.quantidade = quantidade;
        this.material = material;
        this.cor = cor;
        this.tipo = tipo;
        this.estado = estado;
    }

    
    
    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
    public void abrir (){
        setEstado("Aberta");
    }
    public void fechar () {
        setEstado("Fechada");
       
    }
    public void verificarEstado () {
        if (this.estado == "Aberta"){
            System.out.println("A porta esta aberta");
            
        } else {
            System.out.println("A porta esta fechada");
        }
    }
    
    public void abrirJanela (Sistema_eletrico siseletrico) {
         if (siseletrico.isEstado()) {
             setJanela(true);
             System.out.println("Janela aberta");
        } else {
             System.out.println("Não é possivel baixar os vidros, o sistema eletrico está desligado.");
         }
       
        
    }
    
    public void fecharJanela () {
        setJanela(false);
    }
    
    public void verificarJanelas () {
        if (this.janela == true) {
            System.out.println("Janela aberta");
        } else {
            System.out.println("Janela fechada");
        }
        
    }
    
}
