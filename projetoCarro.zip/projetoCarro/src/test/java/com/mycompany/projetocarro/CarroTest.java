
package com.mycompany.projetocarro;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class CarroTest {
    Carro carro;
    Sistema_combustivel siscumbustivel;
    Sistema_eletrico siseletrico;
    Porta porta;
    
    
    public CarroTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
     siscumbustivel = new Sistema_combustivel();
     siseletrico = new Sistema_eletrico();
     porta = new Porta ();
     carro = new Carro ();
     
     carro.siscombustivel = siscumbustivel;
     carro.siseletrico = siseletrico;
     carro.porta = porta;
     
        
    }
    
    @AfterEach
    public void tearDown() {
    }

    //Test de integracion que comprueba el combustivel y voltagem (cuando ambos son suficientes)
    //Claes usadas: carro, sistema eletrico y sistema de combustivel.
    @Test
    public void estadoCombustivelYVoltagemTest() {
        System.out.println("Dando valores a combustible y voltagem");
        siscumbustivel.setNivelCombustivel(30.0);
        siseletrico.setVoltagem(20.0);
        
        double combustible = siscumbustivel.getNivelCombustivel();
        double voltagem = siseletrico.getVoltagem();
        System.out.println("Combustible: "+combustible+ " Voltagem: "+voltagem);
       
        
        carro.estadoElementos();
        
        //Usando AssertEquals
        assertEquals(30.0, siscumbustivel.getNivelCombustivel());
        assertEquals(20.0, siseletrico.getVoltagem());
    }

   
    @Test
    //Test de integracion que verifica el estado de la puerta y si el carro esta ligado o no.
    //Clases usadas: carro y porta.
    public void verificarportasTest() {
        System.out.println("Dando valores al estado de la puerta");
        
        porta.setEstado("Aberta");
        String puerta = porta.getEstado();
        System.out.println("El estado de la puerta es: "+puerta);
        carro.verificarPortas();
        
        //Usando assertEquals y AssertTrue
        assertEquals("Fechada", porta.getEstado());
        assertTrue(carro.estaLigado());
    }

   
    
}
