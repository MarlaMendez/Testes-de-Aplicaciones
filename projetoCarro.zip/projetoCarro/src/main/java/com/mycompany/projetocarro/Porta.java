
package com.mycompany.projetocarro;


public class Porta {
    int quantidade;
    String material;
    String cor;
    String tipo;
    String estado;

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
    public void abrir (){
        System.out.println("Porta aberta");
    }
    public void fechar () {
        System.out.println("Porta fechada");
    }
    public void verificarEstado () {
        if (this.estado == "Aberta"){
            System.out.println("A porta esta aberta");
            
        } else {
            System.out.println("A porta esta fechada");
        }
    }
    
}
