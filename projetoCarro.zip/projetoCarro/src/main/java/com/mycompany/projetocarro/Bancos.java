
package com.mycompany.projetocarro;


public class Bancos {
    int quantidade;
    String material;
    String cor;
    String tipo;
    String estado;
    double novaAltura;
    String posicao;
    int temperatura;
    
    Sistema_eletrico siseletrico;

    
    public Bancos(int quantidade, String material, String cor, String tipo, String estado, double novaAltura, String posicao,int temperatura, Sistema_eletrico siseletrico) {
        this.quantidade = quantidade;
        this.material = material;
        this.cor = cor;
        this.tipo = tipo;
        this.estado = estado;
        this.novaAltura = novaAltura;
        this.posicao = posicao;
        this.siseletrico = siseletrico;
        this.temperatura = temperatura;
    }
    
    

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getNovaAltura() {
        return novaAltura;
    }

    public void setNovaAltura(double novaAltura) {
        this.novaAltura = novaAltura;
    }

    public String getPosicao() {
        return posicao;
    }

    public void setPosicao(String posicao) {
        this.posicao = posicao;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(int temperatura) {
        this.temperatura = temperatura;
    }
    
    
    
    
    
    
    
    
    public void ajustarEncosto (String posicao) {
        this.posicao = posicao;
        System.out.println("Encosto ajustado");
        
    }
    
    public void ajustarAltura (double novaAltura, Sistema_eletrico siseletrico) {
        boolean estadoEletrico = siseletrico.isEstado();
        
        if ( estadoEletrico == true) {
            this.novaAltura = novaAltura;
            System.out.println("Altura ajustada a: ! " +getNovaAltura());
        } else {
            System.out.println("Não foi possivel ajustar a temperatura, verifique o sistema eletrico");
        }
        
    }
    
    public void verificarEstado () {
        
    }
    
    public void ajustarTemperatura (int temperatura, Sistema_eletrico siseletrico) {
        boolean estadoEletrico = siseletrico.isEstado();
        
        if ( estadoEletrico == true) {
            this.temperatura = temperatura;
            System.out.println("Temperatura ajustada a: ! "+getTemperatura());
        } else {
            System.out.println("Não foi possivel ajustar a temperatura, verifique o sistema eletrico");
        }
        
    }

 
    
}
