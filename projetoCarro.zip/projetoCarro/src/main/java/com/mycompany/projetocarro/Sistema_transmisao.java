
package com.mycompany.projetocarro;


public class Sistema_transmisao {
    String tipo;
    int numeroDeMarchas;
    String material;
    String marca;
    boolean estado;
    int marcha_actual;
    
    Motor motor = new Motor("Jato", 5, 45.00, "Hercules", false);

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getNumeroDeMarchas() {
        return numeroDeMarchas;
    }

    public void setNumeroDeMarchas(int numeroDeMarchas) {
        this.numeroDeMarchas = numeroDeMarchas;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getMarcha_actual() {
        return marcha_actual;
    }

    public void setMarcha_actual(int marcha_actual) {
        this.marcha_actual = marcha_actual;
    }
    
   
    public void trocarMarcha (int marcha) {
        this.marcha_actual = marcha;
    }
    
    public void verificarEstado () {
        
    }
    public void subtituirComponente () {
        int estadoEmbriague = motor.getEmbriague();
        
        if( estadoEmbriague > 2) {
            System.out.println("Trocar componente");
        } else {
            System.out.println("Componente está em perfeitas condiçoes");
        }
        
    }
    
}
