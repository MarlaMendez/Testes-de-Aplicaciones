
package com.mycompany.projetocarro;


public class Sistema_Combustivel {
    String tipoDeCombustivel;
    double capacidade;
    double nivelCombustivel;
    String marca;
    boolean estado;

    public String getTipoDeCombustivel() {
        return tipoDeCombustivel;
    }

    public void setTipoDeCombustivel(String tipoDeCombustivel) {
        this.tipoDeCombustivel = tipoDeCombustivel;
    }

    public double getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(double capacidade) {
        this.capacidade = capacidade;
    }

    public double getNivelCombustivel() {
        return nivelCombustivel;
    }

    public void setNivelCombustivel(double nivelCombustivel) {
        this.nivelCombustivel = nivelCombustivel;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    
    
    public double verificarNivel () {
       return this.nivelCombustivel;
        
    }
    public void abastecer (double quantidade) {
        System.out.println("A quantidade abastecida do tanque é: "+quantidade);
    }
    public void substituirTanque () {
        System.out.println("Substituir o tanque de combustivel");
    }
    
}
