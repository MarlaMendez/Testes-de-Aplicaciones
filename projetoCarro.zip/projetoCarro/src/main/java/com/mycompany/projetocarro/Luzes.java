
package com.mycompany.projetocarro;


public class Luzes {
    String tipo;
    int intensidade;
    String cor;
    boolean estado;
    String modelo;
    
    Sistema_eletrico siseletrico = new Sistema_eletrico (100.00, 2000.00, "Novex", false, "Eletrolux" );

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getIntensidade() {
        return intensidade;
    }

    public void setIntensidade(int intensidade) {
        if (intensidade < 0) {
            throw new IllegalArgumentException("No se puede ingresar un valor negativo");
        }
        this.intensidade = intensidade;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    
    
    
    public void ligar (Sistema_eletrico siseletrico) {
        if (siseletrico.isEstado()) {
            estado = true;
            siseletrico.desgasteBateria();
            System.out.println("Luz ligada");
        } else {
            System.out.println("No se puede prender la luz, el sistema eletrico está apagado");
        }
        
    }
    
    public void desligar () {
        System.out.println("Luz desligada");
    }
    
    public void ajustarIntensidade (int novaIntensidade) {
        this.intensidade = novaIntensidade;
        System.out.println("Luzes ajustadas");
        
    }

    
}
