
package com.mycompany.projetocarro;

public class Freios {
    String tipo;
    String material;
    double tamanho;
    String marca;
    double nivelDesgaste;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getTamanho() {
        return tamanho;
    }

    public void setTamanho(double tamanho) {
        this.tamanho = tamanho;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getNivelDesgaste() {
        return nivelDesgaste;
    }

    public void setNivelDesgaste(double nivelDesgaste) {
        this.nivelDesgaste = nivelDesgaste;
    }
    
    
    public void verificarDesgaste(){
        if (nivelDesgaste > 5){
            System.out.println("Nivel bueno");
        } else {
            
        }
        
    }
    public void substituirPastilhas () {
        System.out.println("Pastilha trocada");
        
    }
    public void ajustarFreio () {
        System.out.println("Freio ajustado!");
        
        
    }
    
}
