
package com.mycompany.projetocarro;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.Duration;
import org.junit.jupiter.api.Timeout;

/**
 *
 * @author Marla
 */
public class PainelTest {
    Painel painel;
    Sistema_direcao sisdirecao;
    Sistema_eletrico siseletrico;
    Sistema_transmisao sistransmisao;
    Sistema_combustivel siscombustivel;
    Freios freios;
    Luzes luzes;
    
    
    
    public PainelTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
  
        sisdirecao = new Sistema_direcao();
        siseletrico = new Sistema_eletrico();
        sistransmisao = new Sistema_transmisao();
        siscombustivel = new Sistema_combustivel();
        freios = new Freios ();
        luzes = new Luzes();
        painel = new Painel ();
        
        painel.sisdirecao = sisdirecao;
        painel.siseletrico = siseletrico;
        painel.sistransmisao = sistransmisao;
        painel.siscombustivel = siscombustivel;
        painel.freios = freios;
        painel.luzes = luzes;
        
        
        
    }
    
    @AfterEach
    public void tearDown() {
    }

   //clases usadas: painel, sistema de direcion, sistema eletrico, sistema de transmision y sistema de combustible.
  //assert utilizado: assertFalse
    @Test
    public void muestrainfoPainelTest() {
        
        System.out.println("Dando valores");
        painel.ligarDisplay(); //lgiando o painel
       
        sisdirecao.setAngulo(30.0);
        String infoDirecao = "Angulo de direção: " + sisdirecao.getAngulo();
        painel.atualizarInformacao(infoDirecao);
        
        siseletrico.setVoltagem(50.0);
        String infoVoltagem = "Voltagem: " + siseletrico.getVoltagem();
        painel.atualizarInformacao(infoVoltagem);
        
        sistransmisao.setMarcha_actual(5);
        String infoMarcha = "Marcha actual: "+ sistransmisao.getMarcha_actual();
        painel.atualizarInformacao(infoMarcha);
        
        siscombustivel.setNivelCombustivel(100.0);
        String infoCombustivel = "Nivel de combustivel: "+ siscombustivel.getNivelCombustivel();
        painel.atualizarInformacao(infoCombustivel);
        
        
        System.out.println("Informacion obtenida de angulo, voltagem, marcha y combustible: "+infoDirecao+infoVoltagem+infoMarcha+infoCombustivel);
        
        
        String display = painel.getDisplay();
       
        System.out.println("Informacion del display: "+ display);
        //usando el assertFalse
        assertFalse(display.isEmpty());         
    }
    
    //---------------------------------------------------------------------------


   
   //Clases usadas: painel y frenos
   //assert utilizado: timeout
    @Test
    public void freiosTest() {
        assertTimeout(Duration.ofSeconds(3), () -> {
        System.out.println("Dando valores");
        painel.ligarDisplay(); //lgiando o painel
        
        freios.setNivelDesgaste(4);
        System.out.println("El nivel de desgaste de los frenos es: " +freios.getNivelDesgaste());
        String desgasteFreios = "Nivel de desgaste de frenos: " +freios.getNivelDesgaste();
        painel.infoFreios(freios);
        });
    }
    
    //Test que verifica que no se ingrese un valor negativo para la intensidad de la luz
    //assert utilizados: assertThrows y assertTrue
    @Test
    public void luzesIntensidadTest() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        luzes.setIntensidade(-5);
    });
        String expectedMessage = "No se puede ingresar un valor negativo";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
       
    }

   
   //clases utilizadas: painel, luzes y sistema eletrico
   //asserts utilizados: assertEquals
    @Test
    public void luzesTest() {
        System.out.println("Dando valores");
        painel.ligarDisplay();
        
        luzes.setIntensidade(30);
        System.out.println("La intensidad actual de la luz es: " +luzes.getIntensidade());
        
        painel.infoLuz(luzes);
        
        assertEquals(60, luzes.getIntensidade());
        assertEquals(200, siseletrico.getVoltagem());
       
    }
  
}
