package com.mycompany.projetocarro;

public class Porta {

    int quantidade;
    String material;
    String cor;
    String tipo;
    String estado;
    boolean janela;
    Sistema_eletrico siseletrico;

    public Porta(int quantidade, String material, String cor, String tipo, String estado, Sistema_eletrico siseletrico) {
        this.quantidade = quantidade;
        this.material = material;
        this.cor = cor;
        this.tipo = tipo;
        this.estado = estado;
        this.siseletrico = siseletrico;
    }

    public boolean isJanela() {
        return janela;
    }

    public void setJanela(boolean janela) {
        this.janela = janela;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void abrir() {
        this.estado = "Aberta";
        System.out.println("Porta aberta!");
    }

    public void fechar() {
        this.estado = "Fechada";
        System.out.println("Porta fechada");

    }

    public void verificarEstado() {
        if (this.estado == "Aberta") {
            System.out.println("A porta esta aberta");

        } else {
            System.out.println("A porta esta fechada");
        }
    }

    public void abrirJanela() {
        if (siseletrico.isEstado()) {
            this.janela = true;
            System.out.println("Janela aberta");
        } else {
            System.out.println("Não é possivel baixar os vidros, o sistema eletrico está desligado.");
        }

    }

    public void fecharJanela() {
        this.janela = false;
    }

    public void verificarJanelas() {
        if (this.janela == true) {
            System.out.println("Janela aberta");
        } else {
            System.out.println("Janela fechada");
        }

    }

}
