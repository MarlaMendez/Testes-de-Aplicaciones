
package com.mycompany.projetocarro;


public class Bancos {
    int quantidade;
    String material;
    String cor;
    String tipo;
    String estado;
    double novaAltura;
    String posicao;

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
    
    
    public void ajustarEncosto (String posicao) {
        this.posicao = posicao;
        System.out.println("Encosto ajustado");
        
    }
    
    public void ajustarAltura (double novaAltura) {
        this.novaAltura = novaAltura;
        System.out.println("Altura ajustada");
        
    }
    
    public void verificarEstado () {
        
    }

 
    
}
