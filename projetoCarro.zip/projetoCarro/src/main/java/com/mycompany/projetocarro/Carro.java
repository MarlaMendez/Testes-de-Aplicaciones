
package com.mycompany.projetocarro;

import java.util.ArrayList;
import java.util.List;

public class Carro {
   
    String modelo;
    int ano;
    String cor;
    String placa;
    double quilometragem; 
    boolean ligado; 
    int embriague;
    

    //constructor
    public Carro(String modelo, int ano, String cor, String placa, double quilometragem, boolean ligado) {
        this.modelo = modelo;
        this.ano = ano;
        this.cor = cor;
        this.placa = placa;
        this.quilometragem = quilometragem;
        this.ligado = ligado;
    }
    
    //instanciando clases
    Sistema_combustivel siscombustivel = new Sistema_combustivel ("Diesel", 500.00, 20.00, "Petrobas", true);
    Sistema_eletrico siseletrico = new Sistema_eletrico (100.00, 2000.00, "Novex", false, "Eletrolux" );
    Porta porta = new Porta (4, "Metal", "Branco", "Forte", "Fechada");
    Bancos bancos = new Bancos();
    Suspensao suspensao = new Suspensao ();
    Motor motor = new Motor("Jato", 5, 45.00, "Hercules", false);
    Painel painel = new Painel ();
    
    List<String> caracteristicas = new ArrayList<>();
    
    
    
    //getters and setters
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getQuilometragem() {
        return quilometragem;
    }
    

    public void setQuilometragem(double quilometragem) {
        this.quilometragem = quilometragem;
    }

    public List<String> getCaracteristicas() {
        return caracteristicas;
    }
    
    
    //metodos para integracion de classes y otros
    public void mostrarCaracteristicasCarro(String modelo, int ano, String cor, String placa ){
        this.modelo = modelo;
        this.ano = ano;
        this.cor = cor;
        this.placa = placa;
        
        String informacion = "Informação do carro: " + modelo + " " + ano + " " + cor + " " + placa;
        caracteristicas.add(informacion);
        
    }
    public void ligar (Motor motor) {
        if( motor.isEstado()) {
            ligado = true;
            System.out.println("Carro ligado");
        } else {
            System.out.println("Nao foi possivel ligar o carro, verifique o motor!");
        }
        
        
    }
    public void desligar () {
        ligado = false;
        System.out.println("Carro desligado");
    }
    public void actualizarQuilometragem () {
        
        System.out.println("Kilometragem nova "+this.quilometragem);
    }
    
     public boolean estaLigado() {
         return ligado;
     }
     
     public void moverCarro () {
         this.quilometragem = this.quilometragem + 1;
         System.out.println("Carro em movimento");
     }
     
     public void acelerarCarro (){
         motor.aumentaEmbriague();
         
     }
  //----------------------------------------------
    public void estadoElementos () {
       
       double gasolinaActual = siscombustivel.getNivelCombustivel();
       double voltagemActual = siseletrico.getVoltagem();
       
       boolean estadoMotor = motor.isEstado(); //obtendo estado do motor
       
       if ( estadoMotor == false) { //verificando o estado do motor
           motor.ligar();
           ligar(motor);
       }
       
       
       if (gasolinaActual > 10 && voltagemActual > 10) {
           moverCarro();
       } else {
           System.out.println("Nivel de gasolina, voltagem insuficientes, porfavor abastecer e substituir bateria!");
           siscombustivel.abastecer(100);
           siseletrico.substituirBateria();
           moverCarro();
       }
   }
    
   //------------------------------------------------
    
    
    public void verificarPortas () {
        String estadoPorta;
        
        estadoPorta = porta.getEstado();
        
        
        
        if (estadoPorta == "Fechada") {
            porta.abrir();
            
            boolean estadoMotor = motor.isEstado();
            boolean estadoEletrico = siseletrico.isEstado();
            
            
            if ( estadoMotor == false && estadoEletrico == false) { //verifica se motor e sistema eletrico estao desligados
                motor.ligar(); //liga o motor
                siseletrico.setEstado(true); //"liga" o sistema eletrico
                
                porta.abrirJanela(siseletrico); //abre as janelas
                
                porta.fechar();
                
                ligar(motor); //lliga o carro
                
                
            } else if (estadoPorta == "Aberta") {
                porta.fechar();
                
                if ( estadoMotor == false && estadoEletrico == false) { //verifica se motor e sistema eletrico estao desligados
                motor.ligar(); //liga o motor
                siseletrico.setEstado(true); //"liga" o sistema eletrico
                
                porta.abrirJanela(siseletrico); //abre as janelas
                porta.fechar();
                ligar(motor); //lliga o carro
            } 
                
                
                
            } 
        }

    }
    
    //-------------------------------------------------------
    
    public void bancoAjustado () {
        bancos.ajustarAltura(100);
        bancos.ajustarEncosto("Adelante");
        motor.ligar();
        ligar(motor);
    }
    
    //---------------------------------------------------
    
    public void verificarPneusSuspensao (){
        suspensao.verificarEstadoElementos();
    }
 
}
