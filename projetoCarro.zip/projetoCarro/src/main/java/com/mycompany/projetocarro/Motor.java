
package com.mycompany.projetocarro;


public class Motor {
    String tipo;
    int potencia;
    double cilindrada;
    String marca;
    boolean estado;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public double getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(double cilindrada) {
        this.cilindrada = cilindrada;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    
    
    public void ligar () {
        System.out.println("Motor ligado");
    }
    
    public void desligar () {
        System.out.println("Motor desligado");
    }
    
    public void verificarEstado () {
        if (this.estado == true){
            System.out.println("O motor está ligado");
        } else {
            System.out.println("O motor está desligado");
        }
    }
    
}
