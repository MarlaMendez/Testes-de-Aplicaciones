
package com.mycompany.projetocarro;

public class Painel {
    String tipo;
    String display;
    boolean controle;
    String marca;
    boolean estado;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDisplay() {
        return display;
    }

    public void setDisplay(String display) {
        this.display = display;
    }

    public boolean isControle() {
        return controle;
    }

    public void setControle(boolean controle) {
        this.controle = controle;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    
    
    public void ligarDisplay() {
        System.out.println("O display està ligado");
    }
    
    public void desligarDisplay() {
        System.out.println("O display està desligado");
    }
    
    public void atualizarInformacao(String info) {
        this.display = info;
        System.out.println("Informacion del painel: "+info);
    }
    
    /*Implementando a integraçao da clase Sistema de direçao, clase sistema eletrico,
    clase sistema de transmisao com clase Painel 
    */
    
    public void infoDirecao (Sistema_direcao sisdirecao) {
         String info = "Angulo de direção: " + sisdirecao.getAngulo();
         atualizarInformacao(info);

    }
    
    public void infoEletrico (Sistema_eletrico siseletrico) {
         String info = "Informacion de voltagem: " + siseletrico.getVoltagem();
         atualizarInformacao(info);
    }
    
    public void infoTransmisao (Sistema_transmisao sistransmisao) {
        String info = "Marcha actual: " + sistransmisao.getMarcha_actual();
        atualizarInformacao(info);

    }
    
}
