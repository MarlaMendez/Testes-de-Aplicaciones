
package com.mycompany.projetocarro;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;



public class CarroTest {
    Carro carro;
    Sistema_combustivel siscombustivel;
    Sistema_eletrico siseletrico;
    Porta porta;
    Bancos bancos;
    Pneus pneus;
    Suspensao suspensao;
    Motor motor;
    Painel painel;
    Sistema_direcao sisdirecao;
    Sistema_transmisao sistransmisao;
    
    public CarroTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
          
        
     siscombustivel = new Sistema_combustivel ("Diesel", 500.00, 20.00, "Petrobas", true);
     siseletrico = new Sistema_eletrico (30.00, 2000.00, "Novex","Eletrolux", true );
     porta = new Porta (4, "Metal", "Branco", "Forte", "Aberta", siseletrico);
     carro = new Carro ("K12", 2010, "Branco", "AB-1234", 150.00, motor);
     bancos = new Bancos(4, "Fofo", "Vermelho", "Couro", "Bom estado", 10.00, "Deitado", 20, siseletrico );
     pneus = new Pneus ("Grande", "Borracha", 30.00, "Xing", true, 10, suspensao);
     suspensao = new Suspensao ("Multilink", "Ferro", 10.00, 10, "Petrobaz", 45, false);
     motor = new Motor("Jato", 5, 45.00, "Hercules", true,0, siscombustivel);
     painel = new Painel();
     sisdirecao = new Sistema_direcao("Assistido", true, "Metal", 55.00, "Otimox", 90.00, siseletrico);
     sistransmisao = new Sistema_transmisao("Manual e automatica", 5, "Metal", "Lux", 0, motor);
     
     carro.siscombustivel = siscombustivel;
     carro.siseletrico = siseletrico;
     carro.porta = porta;
     carro.bancos = bancos;
     carro.suspensao = suspensao;
     carro.painel = painel;
     carro.sistransmisao = sistransmisao;
     carro.motor = motor;
     carro.pneus = pneus;
     carro.painel = painel;
     carro.sisdirecao = sisdirecao;
     
     
        //carro.ligar();
        //carro.desligar();
        
        //siseletrico.ligarEletrico();
        //siseletrico.desligarEletrico();
        
        //motor.ligar();
        //motor.desligar();
        
        //sistransmisao.ligarTransmisao();
        //sistransmisao.desligarTransmisao();    
        
     

     
        
    }
    
    @AfterEach
    public void tearDown() {
    }
    
    

    //------------------------------------------------------------------
    
    
    
    @Test
    public void verificarCarroTest() {
        System.out.println("** Teste carro ligado ou nao **");
        
        
        
        carro.verificarCarro();
        
        System.out.println("O carro está ligado: " +carro.estaLigado());
        
        assertTrue(carro.estaLigado());
    }
    
    //------------------------------------------------------------------------

   
    @Test
    public void verificarJanelasTest() {
        System.out.println(" ** Test verificar janelas ** ");
        
      
        
        carro.verificarJanelas();
        
        System.out.println("Estado da janela é: "+ porta.isJanela());
        System.out.println("Estado portas: " +porta.getEstado());
        System.out.println("----------------------------------------------\n");
        
        
        
        
        
        //Usando assertEquals y AssertTrue
        assertEquals("Aberta", porta.getEstado());
        assertTrue(carro.porta.isJanela());
        
    }
    
    //--------------------------------------------------------------------------
    
    
    @Test
    public void ajustarBancosTemperatura_AlturaTest (){
        System.out.println("** Test bancos, temperatura, altura **");
        
        
        carro.ajustarBancosTemperatura_Altura();
        
        
        System.out.println("Valor de la altura del banco : " +bancos.getNovaAltura());
        System.out.println("Valor de la temperatura del banco : " +bancos.getTemperatura());
        System.out.println("----------------------------------------------\n");
        
        
        assertEquals(120, bancos.getNovaAltura());
        assertEquals(30, bancos.getTemperatura());
        
        
        
    }
    
    //-------------------------------------------------------------------------
    
    
    @Test
    public void verificarTransmissaoTest () {
        System.out.println("** Test verificar Transmissao **");
        
        
        carro.verificarTransmissao();
        
        System.out.println("El estado del sistema de transmision es: "+sistransmisao.isEstado());   
        System.out.println("--------------------------------------------\n");
        
        assertTrue(carro.sistransmisao.isEstado());
        
    }
    
    //---------------------------------------------------------------------------
    
    
    @Test
    public void caracteristicasCarro (){
        System.out.println("** Test caracteristicas del carro **");
        
        carro.mostrarCaracteristicasCarro("Chevrolet", 1990, "Vermelho", "CD-12345");
        
        List<String> caracEsperada = List.of("Informação do carro: Chevrolet 1990 Vermelho CD-12345");
        assertLinesMatch(caracEsperada, carro.getCaracteristicas());
    }
    
    // ------------------------------------------------------------------------------
    
    
    
    
    @Test
    public void tocarBocinaTest(){
        System.out.println("** Test tocar bocina **");
        
        
        carro.tocarBocina();
        
        System.out.println("A bocina foi apertada?:  "+sisdirecao.isBocina());
        
        System.out.println("----------------------------------------------\n");
        
        assertTrue(sisdirecao.isBocina());
        
        
    }
    
    // --------------------------------------------------------------------
    
    @Test
    public void andarCarroTest() {
        System.out.println(" ** Test verificar quilometragem **");
        
        carro.andarCarro();
        
        System.out.println("Estado da quilometragem "+carro.getQuilometragem());
        
        assertNotEquals(150, carro.getQuilometragem());
    }
    
    // --------------------------------------------------------------------
    
    @Test
    public void verificarDesgasteSuspensao_PneusTest() {
        System.out.println("** Test desgaste rodas ** ");
        
        System.out.println("Desgaste da roda: "+pneus.getDesgaste());
        
        carro.verificarDesgasteSuspensao_Pneus();
        
        assertTrue(pneus.isMensagemRodas());
    }
    
    // --------------------------------------------------------------------
    
    @Test
    public void verificarEmbriague_MarchaTest() {
        System.out.println(" ** Teste verificar marcha **");
        
        
        carro.verificarEmbriague_Marcha();
        
        System.out.println("Marcha actual: "+sistransmisao.getMarcha_actual());
        System.out.println("Valor do embriague: "+motor.getEmbriague());
        
        assertEquals (4, carro.sistransmisao.getMarcha_actual());
        assertEquals (1, motor.getEmbriague());

        
    }
    
    // -----------------------------------------------------------------
    
    @Test
    public void girarVolanteTest() {
        System.out.println("** Test volante **");
        
        carro.girarVolante();
        
        assertTrue(carro.sisdirecao.isVolanteIzq());
        
        System.out.println("Voltante girou a esquerda?: "+carro.sisdirecao.isVolanteIzq());
    }
}
