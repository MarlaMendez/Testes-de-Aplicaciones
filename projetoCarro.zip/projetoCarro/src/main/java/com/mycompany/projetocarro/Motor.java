
package com.mycompany.projetocarro;


public class Motor {
    String tipo;
    int potencia;
    double cilindrada;
    String marca;
    boolean estado = false;
    int embriague;
    boolean estadoEmbriaguePedal;
    
    Sistema_combustivel siscombustivel;
    
   
    public Motor(String tipo, int potencia, double cilindrada, String marca, boolean estadoEmbriague, int embriague, Sistema_combustivel siscombustivel) {
        this.tipo = tipo;
        this.potencia = potencia;
        this.cilindrada = cilindrada;
        this.marca = marca;
        this.siscombustivel = siscombustivel;
        this.estadoEmbriaguePedal = estadoEmbriague;
        this.embriague = embriague; 
        
    }
    
    public boolean isEstadoEmbriague() {
        return estadoEmbriaguePedal;
    }

    public void setEstadoEmbriague(boolean estadoEmbriague) {
        this.estadoEmbriaguePedal = estadoEmbriague;
    }
    
    
    

    public int getEmbriague() {
        return embriague;
    }

    public void setEmbriague(int embriague) {
        this.embriague = embriague;
    }
    
    
    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public double getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(double cilindrada) {
        this.cilindrada = cilindrada;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isEstado() {
        return this.estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    
    
    public void ligar () {
        boolean estadoCombustible = siscombustivel.isEstado();
        double nivelCombustible = siscombustivel.getNivelCombustivel();
        
        if ( estadoCombustible == true && nivelCombustible > 0) {
            this.estado = true;
            System.out.println("Motor ligado");
        } else {
            System.out.println("Não foi possivel ligar o motor, o sistema de combustivel nao esta funcionando ou esta sem gasolina!");
        }
        
    }
    
    public void desligar () {
        this.estado = false;
        System.out.println("Motor desligado");
    }
    
    public void verificarEstado () {
        if (this.estado == true){
            System.out.println("O motor está ligado");
        } else {
            System.out.println("O motor está desligado");
        }
    }
    
    public void reparar() {
        if (!estado) {
            System.out.println("Reparando o motor");
            estado = true; 
            System.out.println("Motor reparado e ligado novamente.");
        } else {
            System.out.println("O motor já está funcionando, não é necessário reparar.");
        }
    }
    
    public void aumentaEmbriague() {
        this.embriague = this.embriague + 1;
    }
    
    public void pisarPedalEmbriague () { //acto de pisar o pedal 
        this.estadoEmbriaguePedal = true;
    }
    
    public void soltarPedalEmbriague () { //acto de soltar o pedal
        this.estadoEmbriaguePedal = false;
    }
}
