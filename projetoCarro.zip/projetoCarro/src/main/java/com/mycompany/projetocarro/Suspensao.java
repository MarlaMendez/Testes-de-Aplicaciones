
package com.mycompany.projetocarro;


public class Suspensao {
    String tipo;
    String material;
    double altura;
    int rigidez;
    String marca;
    int limitDesgasteAmortiguador = 50;
    int amortiguador;
    boolean estadoSuspensao;
    

    public Suspensao(String tipo, String material, double altura, int rigidez, String marca, int amortiguador, boolean estadoSuspensao) {
        this.tipo = tipo;
        this.material = material;
        this.altura = altura;
        this.rigidez = rigidez;
        this.marca = marca;
        this.amortiguador = amortiguador;
    }

    public boolean isEstadoSuspensao() {
        return estadoSuspensao;
    }

    public void setEstadoSuspensao(boolean estadoSuspensao) {
        this.estadoSuspensao = estadoSuspensao;
    }
    
    

    public int getAmortiguador() {
        return amortiguador;
    }

    public void setAmortiguador(int amortiguador) {
        this.amortiguador = amortiguador;
    }
    

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public int getRigidez() {
        return rigidez;
    }

    public void setRigidez(int rigidez) {
        this.rigidez = rigidez;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    public void ajustarAltura(double novaAltura) {
        System.out.println("Altura ajustada");
        
    }
    
    
    public void desgasteSuspensao() {
        int estadoAmortiguador = getAmortiguador();
        
        if ( estadoAmortiguador > 10) {
            System.out.println("Suspensao não esta boa, pode gerar desgaste em rodas, e outros componentes!");
            
        } else {
            System.out.println("Suspensao está boa");
            
        }
        
        
    }
    
    public void desgasteAmortiguadores () {
        this.amortiguador = this.amortiguador + 1;
        
        if( amortiguador >= limitDesgasteAmortiguador ) {
            System.out.println("Trocar Amortiguador da suspensao");
        } else {
            System.out.println("Componente bom");
        }
        
        
        
    }
    
}
