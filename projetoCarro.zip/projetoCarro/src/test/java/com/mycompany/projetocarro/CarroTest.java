
package com.mycompany.projetocarro;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;



public class CarroTest {
    Carro carro;
    Sistema_combustivel siscumbustivel;
    Sistema_eletrico siseletrico;
    Porta porta;
    Bancos bancos;
    Pneus pneus;
    Suspensao suspensao;
    Motor motor;
    Painel painel;
    Sistema_direcao sisdirecao;
    
    public CarroTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
     siscumbustivel = new Sistema_combustivel();
     siseletrico = new Sistema_eletrico();
     porta = new Porta ();
     carro = new Carro ();
     bancos = new Bancos ();
     pneus = new Pneus ();
     suspensao = new Suspensao ();
     motor = new Motor();
     painel = new Painel();
     sisdirecao = new Sistema_direcao();
     
     carro.siscombustivel = siscumbustivel;
     carro.siseletrico = siseletrico;
     carro.porta = porta;
     carro.bancos = bancos;
     suspensao.pneus = pneus;
     suspensao.motor = motor;
     suspensao.sisdirecao = sisdirecao;
     carro.suspensao = suspensao;
     carro.painel = painel;
     
     
     
        
    }
    
    @AfterEach
    public void tearDown() {
    }

    //------------------------------------------------------------------
    
    
    //Claes usadas: carro, sistema eletrico, sistema de combustivel y motor.
    @Test
    public void estadoCombustivelYVoltagemYMotorTest() {
        System.out.println("Dando valores a combustible y voltagem");
        siscumbustivel.setNivelCombustivel(30.0);
        siseletrico.setVoltagem(20.0);
        
        double combustible = siscumbustivel.getNivelCombustivel();
        double voltagem = siseletrico.getVoltagem();
        System.out.println("Combustible: "+combustible+ " Voltagem: "+voltagem);
       
        
        carro.estadoElementos();
        
        //Usando AssertEquals
        assertEquals(30.0, siscumbustivel.getNivelCombustivel());
        assertEquals(20.0, siseletrico.getVoltagem());
        assertTrue(carro.motor.isEstado());
    }
    
    //------------------------------------------------------------------------

   
    @Test
    
    //Clases usadas: carro, porta, y painel.
    public void verificarportasTest() {
        System.out.println("Dando valores al estado de la puerta");
        
        porta.setEstado("Aberta");
        String puerta = porta.getEstado();
        System.out.println("El estado de la puerta es: "+puerta);
       
        carro.verificarPortas();
        
        
        //Usando assertEquals y AssertTrue
        assertEquals("Fechada", porta.getEstado());
        assertTrue(carro.estaLigado());
        String mensajeEsperado = "A porta foi fechada. O carro pode ser ligado.";
        assertEquals(mensajeEsperado, painel.getDisplay());
    }
    
    //--------------------------------------------------------------------------
    
    //clases usadas: carro, bancos y motor
    //assert utilizado: assertEquals
    @Test
    public void bancosTest (){
        carro.bancoAjustado();
        assertEquals(100, bancos.getNovaAltura());
        assertEquals("Adelante", bancos.getPosicao());
        assertTrue(carro.motor.isEstado());
    }
    
    //-------------------------------------------------------------------------
    
    
    //Clases usadas en la integracion: carro, suspensao, pneus, motor y sistema de direccion
    //aserts utilizados: assertTrue.
    @Test
    public void pneusysuspensaoTest () {
        pneus.setDesgaste(20);
        sisdirecao.setAngulo(35);
        
        System.out.println("El nivel de desgaste de las ruedas es : " +pneus.getDesgaste());
        System.out.println("El angulo del sistema de direcion es: : " +sisdirecao.getAngulo());
        
        carro.verificarPneusSuspensao();
        
        assertTrue(motor.isEstado());   
        assertTrue(sisdirecao.ComponenteFueSubstituido());
    }
    
    //---------------------------------------------------------------------------
    
    //classe usada: carro
    //assert usado: assertLinesMatch
    @Test
    public void caracteristicasCarro (){
        carro.mostrarCaracteristicasCarro("Chevrolet", 1990, "Vermelho", "CD-12345");
        List<String> caracEsperada = List.of("Informação do carro: Chevrolet 1990 Vermelho CD-12345");
        assertLinesMatch(caracEsperada, carro.getCaracteristicas());
    }

}
