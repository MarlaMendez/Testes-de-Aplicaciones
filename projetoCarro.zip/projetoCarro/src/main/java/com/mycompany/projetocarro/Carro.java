
package com.mycompany.projetocarro;

import java.util.ArrayList;
import java.util.List;

public class Carro {
   
    String modelo;
    int ano;
    String cor;
    String placa;
    double quilometragem;
    double gasolinaActual;
    double voltagemActual;
    boolean ligado = false; 
    
    Sistema_combustivel siscombustivel = new Sistema_combustivel ();
    Sistema_eletrico siseletrico = new Sistema_eletrico ();
    Porta porta = new Porta ();
    Bancos bancos = new Bancos();
    Suspensao suspensao = new Suspensao ();
    List<String> caracteristicas = new ArrayList<>();
    
    
    
    
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getQuilometragem() {
        return quilometragem;
    }
    

    public void setQuilometragem(double quilometragem) {
        this.quilometragem = quilometragem;
    }

    public List<String> getCaracteristicas() {
        return caracteristicas;
    }
    
    
    
    public void mostrarCaracteristicasCarro(String modelo, int ano, String cor, String placa ){
        this.modelo = modelo;
        this.ano = ano;
        this.cor = cor;
        this.placa = placa;
        
        String informacion = "Informação do carro: " + modelo + " " + ano + " " + cor + " " + placa;
        caracteristicas.add(informacion);
        
    }
    public void ligar () {
        ligado = true;
        System.out.println("Carro ligado");
    }
    public void desligar () {
        ligado = false;
        System.out.println("Carro desligado");
    }
    public void actualizarQuilometragem (double km) {
        System.out.println("Kilometragem nova "+quilometragem);
    }
    
     public boolean estaLigado() {
         return ligado;
     }
  //----------------------------------------------
    public void estadoElementos () {
       
       gasolinaActual = siscombustivel.getNivelCombustivel();
       voltagemActual = siseletrico.getVoltagem();
       
       
       if (gasolinaActual > 10 && voltagemActual > 10) {
           ligar();
       } else {
           System.out.println("Nivel de gasolina e voltagem  insuficiente, porfavor abastecer e substituir bateria!");
           siscombustivel.abastecer(100);
           siseletrico.substituirBateria();
           ligar();
       }
   }
    
   //------------------------------------------------
    
    public void verificarPortas () {
        String estadoPorta;
        
        estadoPorta = porta.getEstado();
        
        if (estadoPorta =="Aberta") {
            System.out.println("A porta está aberta, feche-a antes de ligar o carro");
            porta.setEstado("Fechada");
            ligar();
        } else {
            ligar();
        }
        
    }
    
    //-------------------------------------------------------
    
    public void bancoAjustado () {
        bancos.ajustarAltura(100);
        bancos.ajustarEncosto("Adelante");
        ligar();
    }
    
    //---------------------------------------------------
    
    public void verificarPneusSuspensao (){
        suspensao.verificarEstado();
    }
 
}
