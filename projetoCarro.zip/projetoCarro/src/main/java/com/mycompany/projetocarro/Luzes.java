
package com.mycompany.projetocarro;


public class Luzes {
    String tipo;
    int intensidade;
    String cor;
    boolean estado;
    String modelo;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getIntensidade() {
        return intensidade;
    }

    public void setIntensidade(int intensidade) {
        this.intensidade = intensidade;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    
    
    
    public void ligar () {
        System.out.println("Luz ligada");
    }
    
    public void desligar () {
        System.out.println("Luz desligada");
    }
    
    public void ajustarIntensidade (int novaIntensidade) {
        System.out.println("Luzes ajustadas");
        
    }

    
}
