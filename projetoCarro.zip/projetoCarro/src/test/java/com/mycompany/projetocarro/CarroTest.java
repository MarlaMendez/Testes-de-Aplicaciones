
package com.mycompany.projetocarro;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;



public class CarroTest {
    Carro carro;
    Sistema_combustivel siscumbustivel;
    Sistema_eletrico siseletrico;
    Porta porta;
    Bancos bancos;
    Pneus pneus;
    Suspensao suspensao;
    Motor motor;
    
    
    public CarroTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
     siscumbustivel = new Sistema_combustivel();
     siseletrico = new Sistema_eletrico();
     porta = new Porta ();
     carro = new Carro ();
     bancos = new Bancos ();
     pneus = new Pneus ();
     suspensao = new Suspensao ();
     motor = new Motor();
     
     carro.siscombustivel = siscumbustivel;
     carro.siseletrico = siseletrico;
     carro.porta = porta;
     carro.bancos = bancos;
     suspensao.pneus = pneus;
     suspensao.motor = motor;
     carro.suspensao = suspensao;
     
     
        
    }
    
    @AfterEach
    public void tearDown() {
    }

    //Test de integracion que comprueba el combustivel y voltagem (cuando ambos son suficientes)
    //Claes usadas: carro, sistema eletrico y sistema de combustivel.
    @Test
    public void estadoCombustivelYVoltagemTest() {
        System.out.println("Dando valores a combustible y voltagem");
        siscumbustivel.setNivelCombustivel(30.0);
        siseletrico.setVoltagem(20.0);
        
        double combustible = siscumbustivel.getNivelCombustivel();
        double voltagem = siseletrico.getVoltagem();
        System.out.println("Combustible: "+combustible+ " Voltagem: "+voltagem);
       
        
        carro.estadoElementos();
        
        //Usando AssertEquals
        assertEquals(30.0, siscumbustivel.getNivelCombustivel());
        assertEquals(20.0, siseletrico.getVoltagem());
    }

   
    @Test
    //Test de integracion que verifica el estado de la puerta y si el carro esta ligado o no.
    //Clases usadas: carro y porta.
    public void verificarportasTest() {
        System.out.println("Dando valores al estado de la puerta");
        
        porta.setEstado("Aberta");
        String puerta = porta.getEstado();
        System.out.println("El estado de la puerta es: "+puerta);
        carro.verificarPortas();
        
        //Usando assertEquals y AssertTrue
        assertEquals("Fechada", porta.getEstado());
        assertTrue(carro.estaLigado());
    }
    
    //Test que verifica si los bancos fueron ajustados correctamente
    //clases usadas en la integracion: carro y bancos
    //assert utilizado: assertEquals
    @Test
    public void bancosTest (){
        carro.bancoAjustado();
        assertEquals(100, bancos.getNovaAltura());
        assertEquals("Adelante", bancos.getPosicao());  
    }
    
    //Test que verifica la integrigad de los pneus y suspensao, y si el motor esta ligado o no.
    //Clases usadas en la integracion: carro, suspensao, pneus y motor
    //aserts utilizados: assertTrue.
    @Test
    public void pneusysuspensaoTest () {
        pneus.setDesgaste(20);
        System.out.println("El nivel de desgaste de las ruedas es: " +pneus.getDesgaste());
        carro.verificarPneusSuspensao();
        assertTrue(motor.isEstado());   
    }
    
    //Test que muestra las caracteristicas del auto y verifica si la informacion coincide
    //classe usada: carro
    //assert usado: assertLinesMatch
    @Test
    public void caracteristicasCarro (){
        carro.mostrarCaracteristicasCarro("Chevrolet", 1990, "Vermelho", "CD-12345");
        List<String> caracEsperada = List.of("Informação do carro: Chevrolet 1990 Vermelho CD-12345");
        assertLinesMatch(caracEsperada, carro.getCaracteristicas());
    }

}
