
package com.mycompany.projetocarro;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Marla
 */
public class PainelTest {
    
    public PainelTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getTipo method, of class Painel.
     */
    @Test
    public void testGetTipo() {
        System.out.println("getTipo");
        Painel instance = new Painel();
        String expResult = "";
        String result = instance.getTipo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTipo method, of class Painel.
     */
    @Test
    public void testSetTipo() {
        System.out.println("setTipo");
        String tipo = "";
        Painel instance = new Painel();
        instance.setTipo(tipo);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDisplay method, of class Painel.
     */
    @Test
    public void testGetDisplay() {
        System.out.println("getDisplay");
        Painel instance = new Painel();
        String expResult = "";
        String result = instance.getDisplay();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDisplay method, of class Painel.
     */
    @Test
    public void testSetDisplay() {
        System.out.println("setDisplay");
        String display = "";
        Painel instance = new Painel();
        instance.setDisplay(display);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isControle method, of class Painel.
     */
    @Test
    public void testIsControle() {
        System.out.println("isControle");
        Painel instance = new Painel();
        boolean expResult = false;
        boolean result = instance.isControle();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setControle method, of class Painel.
     */
    @Test
    public void testSetControle() {
        System.out.println("setControle");
        boolean controle = false;
        Painel instance = new Painel();
        instance.setControle(controle);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMarca method, of class Painel.
     */
    @Test
    public void testGetMarca() {
        System.out.println("getMarca");
        Painel instance = new Painel();
        String expResult = "";
        String result = instance.getMarca();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setMarca method, of class Painel.
     */
    @Test
    public void testSetMarca() {
        System.out.println("setMarca");
        String marca = "";
        Painel instance = new Painel();
        instance.setMarca(marca);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isEstado method, of class Painel.
     */
    @Test
    public void testIsEstado() {
        System.out.println("isEstado");
        Painel instance = new Painel();
        boolean expResult = false;
        boolean result = instance.isEstado();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setEstado method, of class Painel.
     */
    @Test
    public void testSetEstado() {
        System.out.println("setEstado");
        boolean estado = false;
        Painel instance = new Painel();
        instance.setEstado(estado);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ligarDisplay method, of class Painel.
     */
    @Test
    public void testLigarDisplay() {
        System.out.println("ligarDisplay");
        Painel instance = new Painel();
        instance.ligarDisplay();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of desligarDisplay method, of class Painel.
     */
    @Test
    public void testDesligarDisplay() {
        System.out.println("desligarDisplay");
        Painel instance = new Painel();
        instance.desligarDisplay();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of atualizarInformacao method, of class Painel.
     */
    @Test
    public void testAtualizarInformacao() {
        System.out.println("atualizarInformacao");
        String info = "";
        Painel instance = new Painel();
        instance.atualizarInformacao(info);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of infoDirecao method, of class Painel.
     */
    @Test
    public void testInfoDirecao() {
        System.out.println("infoDirecao");
        Sistema_direcao sisdirecao = null;
        Painel instance = new Painel();
        instance.infoDirecao(sisdirecao);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of infoEletrico method, of class Painel.
     */
    @Test
    public void testInfoEletrico() {
        System.out.println("infoEletrico");
        Sistema_eletrico siseletrico = null;
        Painel instance = new Painel();
        instance.infoEletrico(siseletrico);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of infoTransmisao method, of class Painel.
     */
    @Test
    public void testInfoTransmisao() {
        System.out.println("infoTransmisao");
        Sistema_transmisao sistransmisao = null;
        Painel instance = new Painel();
        instance.infoTransmisao(sistransmisao);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of infoGasolina method, of class Painel.
     */
    @Test
    public void testInfoGasolina() {
        System.out.println("infoGasolina");
        Sistema_combustivel siscombustivel = null;
        Painel instance = new Painel();
        instance.infoGasolina(siscombustivel);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of infoFreios method, of class Painel.
     */
    @Test
    public void testInfoFreios() {
        System.out.println("infoFreios");
        Freios freios = null;
        Painel instance = new Painel();
        instance.infoFreios(freios);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of infoLuz method, of class Painel.
     */
    @Test
    public void testInfoLuz() {
        System.out.println("infoLuz");
        Luzes luzes = null;
        Painel instance = new Painel();
        instance.infoLuz(luzes);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
