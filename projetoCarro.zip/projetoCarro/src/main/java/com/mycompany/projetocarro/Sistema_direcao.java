
package com.mycompany.projetocarro;

public class Sistema_direcao {
    String tipo;
    boolean assistido;
    String material;
    double relacao;
    String marca;
    double angulo;

    public double getAngulo() {
        return angulo;
    }

    public void setAngulo(double angulo) {
        this.angulo = angulo;
    }
    
    

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isAssistido() {
        return assistido;
    }

    public void setAssistido(boolean assistido) {
        this.assistido = assistido;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getRelacao() {
        return relacao;
    }

    public void setRelacao(double relacao) {
        this.relacao = relacao;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    
    public void ajustarDirecao (double angulo) {
        this.angulo=angulo;
        System.out.println("O angulo foi ajustado");
    }
    
    public void verificarEstado () {
        
    }
    public void substituirComponente (String componente) {
        System.out.println("O componente foi substituido");
    }
    
}
