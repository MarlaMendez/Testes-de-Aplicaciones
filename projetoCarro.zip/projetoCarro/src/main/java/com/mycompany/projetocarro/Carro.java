package com.mycompany.projetocarro;

import java.util.ArrayList;
import java.util.List;

public class Carro {

    String modelo;
    int ano;
    String cor;
    String placa;
    double quilometragem;
    boolean ligado = false;
    int embriague;
    
    Motor motor;

    //constructor
    public Carro(String modelo, int ano, String cor, String placa, double quilometragem, Motor motor) {
        this.modelo = modelo;
        this.ano = ano;
        this.cor = cor;
        this.placa = placa;
        this.quilometragem = quilometragem;
        this.motor = motor;
        
    }

    //instanciando clases
    Sistema_combustivel siscombustivel = new Sistema_combustivel("Diesel", 500.00, 20.00, "Petrobas", true);
    Sistema_eletrico siseletrico = new Sistema_eletrico(0.00, 2000.00, "Novex","Eletrolux", true);
    Porta porta = new Porta(4, "Metal", "Branco", "Forte", "Fechada", siseletrico);
    Bancos bancos = new Bancos(4, "Fofo", "Vermelho", "Couro", "Bom estado", 10.00, "Deitado", 20, siseletrico);
    Suspensao suspensao = new Suspensao("Multilink", "Ferro", 10.00, 10, "Petrobaz", 45, true);
    Painel painel = new Painel();
    Sistema_transmisao sistransmisao = new Sistema_transmisao("Manual e automatica", 5, "Metal", "Lux", 0, motor);
    Pneus pneus = new Pneus("Grande", "Borracha", 30.00, "Xing", true, 10, suspensao);
    Sistema_direcao sisdirecao = new Sistema_direcao("Assistido", true, "Metal", 55.00, "Otimox", 90.00, siseletrico);
    List<String> caracteristicas = new ArrayList<>();

    //getters and setters
    public boolean isLigado() {
        return ligado;
    }

    public void setLigado(boolean ligado) {
        this.ligado = ligado;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getQuilometragem() {
        return quilometragem;
    }

    public void setQuilometragem(double quilometragem) {
        this.quilometragem = quilometragem;
    }

    public List<String> getCaracteristicas() {
        return caracteristicas;
    }

    //metodos para integracion de classes y otros
    public void mostrarCaracteristicasCarro(String modelo, int ano, String cor, String placa) {
        this.modelo = modelo;
        this.ano = ano;
        this.cor = cor;
        this.placa = placa;

        String informacion = "Informação do carro: " + modelo + " " + ano + " " + cor + " " + placa;
        caracteristicas.add(informacion);

    }

    public void ligar() {
        if (motor.isEstado()) {
            ligado = true;
            System.out.println("Carro ligado");
        } else {
            System.out.println("Nao foi possivel ligar o carro, verifique o motor!");
        }

    }

    public void desligar() {
        ligado = false;
        System.out.println("Carro desligado");
    }

    public void actualizarQuilometragem() {
        suspensao.desgasteAmortiguadores();
        System.out.println("Kilometragem nova " + this.quilometragem);
    }

    public boolean estaLigado() {
        return ligado;
    }

    public void moverCarro() {
        this.quilometragem = this.quilometragem + 1;
        System.out.println("Carro em movimento");
    }

    public void acelerarCarro() {
        motor.aumentaEmbriague();
        System.out.println("Acelerando vrrrummmm");

    }

    // METODOS DE INTEGRACION
    //----------------------------------------------
    // carro y motor
    public void verificarCarro() {

        boolean estadoMotor = motor.isEstado();

        if (estadoMotor == true) { //verificando o estado do motor
            ligar(); //liga o carro

        } else if (estadoMotor == false) {
            System.out.println("Não foi possivel ligar o carro, ligue o motor primeiro");
        }

    }

    //------------------------------------------------
    // porta e sistema eletrico 
    public void verificarJanelas() {
        String estadoPorta;

        estadoPorta = porta.getEstado();
        boolean estadoEletrico = siseletrico.isEstado();

        if (estadoPorta == "Aberta" && estadoEletrico == true ) {
            porta.abrirJanela(); //abre as janelas
        }
        if (estadoPorta == "Fechada") {
            System.out.println("A porta está fechada, abra primeiro para começar");
        }

    }

    //-------------------------------------------------------
    // bancos y sistema eletrico 
    public void ajustarBancosTemperatura_Altura() {
        boolean estadoEletrico = siseletrico.isEstado();

        if (estadoEletrico == true) {
            bancos.ajustarTemperatura(30, siseletrico);
            bancos.ajustarAltura(120, siseletrico);

        } else if (estadoEletrico == false) {
            System.out.println("Sistema eletrico desligado!");

        }

    }

    //---------------------------------------------------
    // Motor y sistema de transmissao
    public void verificarTransmissao() {
        // primeira obtençao de valores
        boolean estadoMotor = motor.isEstado();

        if (estadoMotor == true) {
            sistransmisao.ligarTransmisao();
            
        } else if (estadoMotor == false) {
            System.out.println("Não foi possivel ligar o sistema de trnasmissão, ligue o motor primeiro");
        }

    }

    // ----------------------------------------
    // sistema eletrico e sistema de direcion
    public void tocarBocina() {

        boolean estadoEletrico = siseletrico.isEstado();

        if (estadoEletrico == false) {
            System.out.println("Sistema eletrico desligado, ligue-o");
        } else if (estadoEletrico == true) {
            System.out.println("Sistema eletrico já esta ligado");
            sisdirecao.bocinaVolante();
        }

    }

    // ---------------------------------------------------------------
    // motor, sistema eletrico y sistema de combustivel 
    public void andarCarro() {
        double gasolinaActual = siscombustivel.getNivelCombustivel();
        double voltagemActual = siseletrico.getVoltagem();
        boolean estadoEletrico = siseletrico.isEstado();
        boolean estadoMotor = motor.isEstado();

        if (estadoMotor = true && estadoEletrico == true) {
            if (gasolinaActual > 0 && voltagemActual > 0) {
                ligar();
                moverCarro();
                actualizarQuilometragem();
            } else {
                System.out.println("Não foi possivel realizar a açao, Verificar gasolina ou voltagem");

            }

        } else {
            System.out.println("Motor ou sistema eletrico desligados ou ambos");
        }
    }

    // -----------------------------------------------------------
    // Suspensao e pneus
    public void verificarDesgasteSuspensao_Pneus() {
        boolean estadoSuspensao = suspensao.isEstadoSuspensao();

        if (estadoSuspensao = true) {
            suspensao.desgasteSuspensao();

            pneus.verificarDesgaste();

        } else {
            System.out.println("Suspensao nao está funcionando corretamente");
        }

    }

    // -------------------------------------------------------------------------
    // motor y sistema de transmissao
    public void verificarEmbriague_Marcha() {
        
        boolean estadoTransmisao = sistransmisao.isEstado();
        boolean estadoEmbriague = motor.isEstadoEmbriague();
        boolean estadoMotor = motor.isEstado();
        
        

        if (estadoMotor == true) {
            ligar();  //ligo o carro
            acelerarCarro(); //acelerar o carro

            if (estadoEmbriague == true && estadoTransmisao == true) {
                sistransmisao.trocarMarcha(4); //trocar a marcha
            } else if (estadoEmbriague == false && estadoTransmisao == false) {
                System.out.println("Nao foi possivel trocar a marcha, verificar embriague o sistema de transmisao");; //trocar a marcha
            }

        } else {
            System.out.println("O motor está desligado, ligue-o primeiro!");
        }

    }

    // ------------------------------------------------------------
    
    // sistema eletrico y sistema de direccion
    public void girarVolante() {
        boolean estadoEletrico = siseletrico.isEstado();
        boolean estadoAssistido = sisdirecao.isAssistido();
        double valorAngulo = sisdirecao.getAngulo();

        if (estadoAssistido == true && valorAngulo <= 50 && estadoEletrico == true) {
            sisdirecao.girarVolanteIzquierda();
        } else if (estadoAssistido == false && valorAngulo > 50) {
            System.out.println("Falla en los componentes");

        }

    }

}
