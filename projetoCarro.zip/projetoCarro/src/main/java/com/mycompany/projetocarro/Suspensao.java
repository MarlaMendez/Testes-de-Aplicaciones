
package com.mycompany.projetocarro;


public class Suspensao {
    String tipo;
    String material;
    double altura;
    int rigidez;
    String marca;
    
    
    Pneus pneus = new Pneus ();
    Motor motor = new Motor ();
    

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public int getRigidez() {
        return rigidez;
    }

    public void setRigidez(int rigidez) {
        this.rigidez = rigidez;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    public void ajustarAltura(double novaAltura) {
        System.out.println("Altura ajustada");
        
    }
    
    public void verificarEstado () {
         int estadoPneus = pneus.getDesgaste();
        
        if (estadoPneus > 10){
            motor.desligar();
            pneus.substituir();
            substituirSuspensao();
            System.out.println("Seu carro está em perfeitas condiçoes agora, jà pode ligar!");
            motor.ligar();
            
        } else {
            System.out.println("Não foi encontrado problemas na suspensão");
            motor.ligar();
        }
        
        
        
    }
    
    public void substituirSuspensao() {
        System.out.println("Suspensao substituida!");
        
    }
    
}
