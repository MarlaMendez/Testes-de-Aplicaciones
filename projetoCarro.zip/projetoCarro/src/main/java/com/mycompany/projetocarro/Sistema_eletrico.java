
package com.mycompany.projetocarro;


public class Sistema_eletrico {
    double voltagem;
    double capacidade;
    String tipoDeBateria;
    boolean estado;
    String marca;

    public double getVoltagem() {
        return voltagem;
    }

    public void setVoltagem(double voltagem) {
        this.voltagem = voltagem;
    }

    public double getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(double capacidade) {
        this.capacidade = capacidade;
    }

    public String getTipoDeBateria() {
        return tipoDeBateria;
    }

    public void setTipoDeBateria(String tipoDeBateria) {
        this.tipoDeBateria = tipoDeBateria;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    public void verificarBateria(double voltagem){
        this.voltagem = voltagem;
        System.out.println("A voltagem da bateria é "+ voltagem);
        
    }
    
    
    public void substituirBateria() {
        System.out.println("A bateria foi substituida");
    }
    
    public void testarSistema() {
        
    }
    
}
