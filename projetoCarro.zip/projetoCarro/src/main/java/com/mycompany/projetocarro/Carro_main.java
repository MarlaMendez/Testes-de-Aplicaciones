
package com.mycompany.projetocarro;

public class Carro_main {
    public static void main(String[] args) {
       
        // instanciando clases
        
     Sistema_combustivel siscombustivel = new Sistema_combustivel ("Diesel", 500.00, 20.00, "Petrobas", true);
     Sistema_eletrico siseletrico = new Sistema_eletrico (30.00, 2000.00, "Novex","Eletrolux", true );
     Porta porta = new Porta (4, "Metal", "Branco", "Forte", "Fechada", siseletrico);
     Motor motor = new Motor("Jato", 5, 45.00, "Hercules", false,0, siscombustivel);
     Carro carro = new Carro ("K12", 2010, "Branco", "AB-1234", 150.00, motor);
     Bancos bancos = new Bancos(4, "Fofo", "Vermelho", "Couro", "Bom estado", 10.00, "Deitado", 20, siseletrico );
     Suspensao suspensao = new Suspensao ("Multilink", "Ferro", 10.00, 10, "Petrobaz", 45, false);
     Pneus pneus = new Pneus ("Grande", "Borracha", 30.00, "Xing", true, 10, suspensao);
     Painel painel = new Painel();
     Sistema_direcao sisdirecao = new Sistema_direcao("Assistido", true, "Metal", 55.00, "Otimox", 90.00, siseletrico);
     Sistema_transmisao sistransmisao = new Sistema_transmisao("Manual e automatica", 5, "Metal", "Lux", 0, motor);
        
        
        
        //carro.ligar();
        //carro.desligar();
        
        //siseletrico.ligarEletrico();
        //siseletrico.desligarEletrico();
        
        //motor.ligar();
        //motor.desligar();
        
        //sistransmisao.ligarTransmisao();
        //sistransmisao.desligarTransmisao();
     
        System.out.println("O carro está ligado?: "+carro.isLigado());
        System.out.println("o Sistema eletrico está ligado?: "+siseletrico.isEstado());
        System.out.println("O motor está ligado?: "+motor.isEstado());
        System.out.println("O sistema de transmissao está ligado: "+sistransmisao.isEstado());
    }
    
  
}
