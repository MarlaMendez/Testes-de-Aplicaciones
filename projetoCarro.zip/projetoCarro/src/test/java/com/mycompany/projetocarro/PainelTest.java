
package com.mycompany.projetocarro;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.Timeout;

/**
 *
 * @author Marla
 */
public class PainelTest {
    Painel painel;
    Sistema_direcao sisdirecao;
    Sistema_eletrico siseletrico;
    Sistema_transmisao sistransmisao;
    Sistema_combustivel siscombustivel;
    Freios freios;
    Luzes luzes;
    Motor motor;
    Pneus pneus;
    
    
    
    public PainelTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
  
        sisdirecao = new Sistema_direcao("Assistido", true, "Metal", 55.00, "Otimox", 90.00, siseletrico);
        siseletrico = new Sistema_eletrico (100.00, 2000.00, "Novex", "Eletrolux", true );
        sistransmisao = new Sistema_transmisao("Manual e automatica", 5, "Metal", "Lux", 0, motor);
        siscombustivel = new Sistema_combustivel ("Diesel", 500.00, 20, "Petrobas", true);
        freios = new Freios("Tambor", "Ferro", 20.00, "Durex", 1.00, pneus);
        luzes = new Luzes("Led", 1, "Branca", "Redonda", siseletrico);
        painel = new Painel ();
        
        painel.sisdirecao = sisdirecao;
        painel.siseletrico = siseletrico;
        painel.sistransmisao = sistransmisao;
        painel.siscombustivel = siscombustivel;
        painel.freios = freios;
        painel.luzes = luzes;
        
        
        //carro.ligar();
        //carro.desligar();
        
        //siseletrico.ligarEletrico();
        //siseletrico.desligarEletrico();
        
        //motor.ligar();
        //motor.desligar();
        
        //sistransmisao.ligarTransmisao();
        //sistransmisao.desligarTransmisao();
        
        
        
    }
    
    @AfterEach
    public void tearDown() {
    }

    
   //clases usadas: painel, sistema de direcion, sistema eletrico, sistema de transmision y sistema de combustible.
  //assert utilizado: assertFalse
    @Test
    public void muestrainfoPainelTest() {
        
        painel.infoDirecao();
        painel.infoEletrico();
        painel.infoGasolina();
        painel.infoSuspensao();
        painel.infoTransmisao();
        
        
        
        String display = painel.getDisplay();
       
        System.out.println("Informacion del display: "+ display);
        //usando el assertFalse
        assertFalse(display.isEmpty());         
    }
    
    //---------------------------------------------------------------------------


   
   //Clases usadas: painel y frenos
   //assert utilizado: timeout, assertTrue, assertequals
    @Test
    public void freiosTest() {
        assertTimeout(Duration.ofSeconds(3), () -> {
        System.out.println("Test Freios, painel");
        
        System.out.println("El estado del painel es: "+painel.isEstado());
        System.out.println("El nivel de desgaste de los frenos es: " +freios.getNivelDesgaste());
        
        System.out.println("----------------------------------------------\n");
        
        
        String frase = "Os freios estão desgastados";
        String fraseFreios = freios.getMensagemDesgaste();
        List<String> mensagemFreios = List.of (frase);
         List<String> mensagemFreios2 = List.of (fraseFreios);
         
         
        
        painel.verificarFreios();
        
        assertTrue(painel.isEstado());
        assertLinesMatch(mensagemFreios, mensagemFreios2);
    
        
        });
   
    }
    
    //Metodo bonus
    //Test que verifica que no se ingrese un valor negativo para la intensidad de la luz
    //assert utilizados: assertThrows y assertTrue
    @Test
    public void luzesIntensidadTest() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        luzes.setIntensidade(-5);
    });
        String expectedMessage = "No se puede ingresar un valor negativo";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
       
    }

    
    
    
   
   //clases utilizadas: painel, luzes y sistema eletrico
   //asserts utilizados: assertEquals
    @Test
    public void luzesTest() {
        System.out.println("Test de luz");
        
        
        System.out.println("La intensidad actual de la luz es: " +luzes.getIntensidade());
        System.out.println("Estado de las luzes: "+luzes.isEstado());
         System.out.println("----------------------------------------------\n");
        
        
        painel.infoLuz(luzes);
        
        assertEquals(60, luzes.getIntensidade());
        assertTrue(luzes.isEstado());
       
    }
  
}
