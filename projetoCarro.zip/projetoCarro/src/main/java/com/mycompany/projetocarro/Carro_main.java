
package com.mycompany.projetocarro;

public class Carro_main {
    public static void main(String[] args) {
        //Instanciando
        Carro carro = new Carro () ;
        Painel painel = new Painel ();
        Sistema_direcao sisdirecao = new Sistema_direcao ();
        Sistema_combustivel siscombustivel = new Sistema_combustivel ();
        Sistema_eletrico siseletrico = new Sistema_eletrico ();
        Porta porta = new Porta ();
        Freios freios = new Freios ();
        Luzes luzes = new Luzes ();
        Pneus pneus = new Pneus ();
        Suspensao suspensao = new Suspensao ();
        
          //Llamando metodo que muestra informacion del carro
        carro.mostrarInfo(" Ferrari ", 2016, " amarillo ", " 1233456 ");
        
        //Colocando valores para o nivel de combustivel e voltagem
        siscombustivel.setNivelCombustivel(20);
        double gasolinaActual = siscombustivel.getNivelCombustivel();
        siseletrico.setVoltagem(15);
        System.out.println("-------------------------\n");
        
        //Ajusta el angulo del carro
        sisdirecao.ajustarDirecao(50);
        
       System.out.println("-------------------------\n");
       
        //Verifica nivel de gasolina del carro
        siscombustivel.verificarNivel(gasolinaActual);
        
        System.out.println("-------------------------\n");
       
        //Verificando voltagem bateria
        siseletrico.verificarBateria(16.7);
        
        System.out.println("-------------------------\n");
      
        
        //Mostra a informação no painel
        painel.infoDirecao(sisdirecao);
        painel.infoGasolina(siscombustivel);
        painel.infoEletrico(siseletrico);
        
        System.out.println("-------------------------\n");
        
       
        //Metodo que verifica voltagem de bateria e nivel de gasolina, e faz a troca de bateria e abastece o carro (se necesario) e depois liga.
        carro.estadoElementos();
        
        System.out.println("-------------------------\n");
        
        //Abrindo as portas
        porta.setEstado("Aberta");
        
        System.out.println("-------------------------\n");
        
        //Verificando o estado da porta para poder ligar o carro
        carro.verificarPortas();
        
        System.out.println("-------------------------\n");
        
        
        //Configurando nivel de desgaste de freios
        freios.setNivelDesgaste(2);
        
        //Verificando o estado dos freios e mostrando no painel
        painel.infoFreios(freios);
        
        System.out.println("--------------------\n");
        
        //Configurando nivel de intensidade das luzes
        luzes.setIntensidade(40);
        
        //Verificando a intensidade das luzes e mostrando no painel 
        painel.infoLuz(luzes);
        
        System.out.println("--------------------\n");
        
        //Ajustando encosto e altura de bancos antes de ligar o carro
        carro.bancoAjustado();
        
        System.out.println("--------------------\n");
        
        //Configurando anos de desgaste de rodas
        pneus.setDesgaste(12);
        
        //Verificando desgaste de rodas para poder fazer substituição de suspensao e rodas
        suspensao.verificarEstado();   
        
    }
    
}
