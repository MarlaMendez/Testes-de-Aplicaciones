
package com.mycompany.projetocarro;

public class Painel {
    String tipo;
    String display;
    boolean controle;
    String marca;
    boolean estado;
    
    Sistema_eletrico siseletrico = new Sistema_eletrico ();
    Sistema_direcao sisdirecao = new Sistema_direcao ();
    Sistema_transmisao sistransmisao = new Sistema_transmisao();
    Sistema_combustivel siscombustivel = new Sistema_combustivel();
    Freios freios = new Freios ();
    Luzes luzes = new Luzes();
    
    

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDisplay() {
        return display;
    }

    public void setDisplay(String display) {
        this.display = display;
    }

    public boolean isControle() {
        return controle;
    }

    public void setControle(boolean controle) {
        this.controle = controle;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    
    
    public void ligarDisplay() {
        System.out.println("O display està ligado");
    }
    
    public void desligarDisplay() {
        System.out.println("O display està desligado");
    }
    
    public void atualizarInformacao(String info) {
        this.display = info;
        System.out.println("Informacion del painel: "+info);
    }
    
    /*Implementando a integraçao da clase Sistema de direçao, clase sistema eletrico,
    clase sistema de transmisao, sistema de combustivel com clase Painel 
    */
    
    public void infoDirecao (Sistema_direcao sisdirecao) {
         String info = "Angulo de direção: " + sisdirecao.getAngulo();
         atualizarInformacao(info);

    }
    
    public void infoEletrico (Sistema_eletrico siseletrico) {
         String info = "Informacion de voltagem: " + siseletrico.getVoltagem();
         atualizarInformacao(info);
    }
    
    public void infoTransmisao (Sistema_transmisao sistransmisao) {
        String info = "Marcha actual: " + sistransmisao.getMarcha_actual();
        atualizarInformacao(info);

    }
    
    public void infoGasolina (Sistema_combustivel siscombustivel) {
        String info = "Nivel de gasolina " + siscombustivel.getNivelCombustivel();
        atualizarInformacao (info);
    }
    
    public void infoFreios (Freios freios) {
        double desgaste = freios.getNivelDesgaste();
        
        if (desgaste < 5) {
            System.out.println("Informacion de painel: Trocar pastilha do carro");
            freios.substituirPastilhas();
            freios.ajustarFreio();
            System.out.println("Já pode ligar o carro normalmente");
            
        } else {
            System.out.println("Freios funcionando correctamente");
        }
    }
    
    public void infoLuz (Luzes luzes) {
        int intensidade = luzes.getIntensidade();
        
        if (intensidade < 50) {
            siseletrico.recargarBateria(200);
            luzes.ligar();
            luzes.ajustarIntensidade(60);
        } else {
            luzes.ligar();
            luzes.ajustarIntensidade(60);
        }
    }
    
}
