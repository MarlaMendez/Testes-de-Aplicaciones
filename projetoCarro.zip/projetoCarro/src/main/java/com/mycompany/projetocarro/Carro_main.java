
package com.mycompany.projetocarro;

public class Carro_main {
    public static void main(String[] args) {
       
        //instanciando clases
        
        Carro carro = new Carro ("K12", 2010, "Branco", "AB-1234", 150.00,false);
        Sistema_combustivel siscombustivel = new Sistema_combustivel ("Diesel", 500.00, 20.00, "Petrobas", true);
        Sistema_eletrico siseletrico = new Sistema_eletrico (100.00, 2000.00, "Novex", false, "Eletrolux" );
        Motor motor = new Motor("Jato", 5, 45.00, "Hercules", false);
        Porta porta = new Porta (4, "Metal", "Branco", "Forte", "Fechada");
    }
    
}
