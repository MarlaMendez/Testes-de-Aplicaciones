
package com.mycompany.projetocarro;

public class Carro {
   
    String modelo;
    int ano;
    String cor;
    String placa;
    double quilometragem;
    
    
    double gasolinaActual;
    double voltagemActual;
    
    Sistema_combustivel siscombustivel = new Sistema_combustivel ();
    Sistema_eletrico siseletrico = new Sistema_eletrico ();
    Porta porta = new Porta ();
    Painel painel = new Painel ();
    Bancos bancos = new Bancos();
    
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getQuilometragem() {
        return quilometragem;
    }
    

    public void setQuilometragem(double quilometragem) {
        this.quilometragem = quilometragem;
    }
    
    public void mostrarInfo(String modelo, int ano, String cor, String placa ){
        this.modelo = modelo;
        this.ano = ano;
        this.cor = cor;
        this.placa = placa;
        
        System.out.println("Informação do carro: "+modelo +ano+cor+placa);
        
    }
    public void ligar () {
        System.out.println("Carro ligado");
    }
    public void desligar () {
        System.out.println("Carro desligado");
    }
    public void actualizarQuilometragem (double km) {
        System.out.println("Kilometragem nova "+quilometragem);
    }
  //----------------------------------------------
    public void estadoElementos () {
       
       gasolinaActual = siscombustivel.getNivelCombustivel();
       voltagemActual = siseletrico.getVoltagem();
       
       
       if (gasolinaActual > 10 && voltagemActual > 10) {
           ligar();
       } else {
           System.out.println("Nivel de gasolina e voltagem  insuficiente, porfavor abastecer e substituir bateria!");
           siscombustivel.abastecer(100);
           siseletrico.substituirBateria();
           ligar();
       }
   }
    
   //------------------------------------------------
    
    public void verificarPortas () {
        String estadoPorta;
        
        estadoPorta = porta.getEstado();
        
        if (estadoPorta =="Aberta") {
            System.out.println("A porta está aberta, feche-a antes de ligar o carro");
            porta.setEstado("Fechada");
            ligar();
        } else {
            ligar();
        }
        
    }
    
    //-------------------------------------------------------
    
    public void bancoAjustado () {
        bancos.ajustarAltura(100);
        bancos.ajustarEncosto("Adelante");
        ligar();
    }
    
    
 
    
    
    
    //Main de la clase carro que llama los metodos.
    public static void main(String[] args) {
        Carro carro = new Carro () ;
        Painel painel = new Painel ();
        Sistema_direcao sisdirecao = new Sistema_direcao ();
        Sistema_combustivel siscombustivel = new Sistema_combustivel ();
        Sistema_eletrico siseletrico = new Sistema_eletrico ();
        Porta porta = new Porta ();
        Freios freios = new Freios ();
        Luzes luzes = new Luzes ();
        Pneus pneus = new Pneus ();
        Suspensao suspensao = new Suspensao ();
        
        //Llamando metodo que muestra informacion del carro
        carro.mostrarInfo(" Ferrari ", 2016, " amarillo ", " 1233456 ");
        //Colocando valores para o nivel de combustivel e voltagem
        siscombustivel.setNivelCombustivel(15);
        siseletrico.setVoltagem(15);
        System.out.println("-------------------------\n");
        
        //Ajusta el angulo del carro
        sisdirecao.ajustarDirecao(50);
        
       System.out.println("-------------------------\n");
       
        //Verifica nivel de gasolina del carro
        siscombustivel.verificarNivel(20);
        
        System.out.println("-------------------------\n");
       
        //Verificando voltagem bateria
        siseletrico.verificarBateria(16.7);
        
        System.out.println("-------------------------\n");
      
        
        //Mostra a informação no painel
        painel.infoDirecao(sisdirecao);
        painel.infoGasolina(siscombustivel);
        painel.infoEletrico(siseletrico);
        
        System.out.println("-------------------------\n");
        
       
        //Metodo que verifica voltagem de bateria e nivel de gasolina, e faz a troca de bateria e abastece o carro (se necesario) e depois liga.
        carro.estadoElementos();
        
        System.out.println("-------------------------\n");
        
        //Abrindo as portas
        porta.setEstado("Aberta");
        
        System.out.println("-------------------------\n");
        
        //Verificando o estado da porta para poder ligar o carro
        carro.verificarPortas();
        
        System.out.println("-------------------------\n");
        
        
        //Configurando nivel de desgaste de freios
        freios.setNivelDesgaste(2);
        
        //Verificando o estado dos freios e mostrando no painel
        painel.infoFreios(freios);
        
        System.out.println("--------------------\n");
        
        //Configurando nivel de intensidade das luzes
        luzes.setIntensidade(40);
        
        //Verificando a intensidade das luzes e mostrando no painel 
        painel.infoLuz(luzes);
        
        System.out.println("--------------------\n");
        
        //Ajustando encosto e altura de bancos antes de ligar o carro
        carro.bancoAjustado();
        
        System.out.println("--------------------\n");
        
        //Configurando anos de desgaste de rodas
        pneus.setDesgaste(12);
        
        //Verificando desgaste de rodas para poder fazer substituição de suspensao e rodas
        suspensao.verificarEstado();
      
        
        
        
        
        
        
        
        
        
        
    }
 
    
}
