
package com.mycompany.projetocarro;


public class Pneus {
    String tamanho;
    String tipo;
    double pressao;
    String marca;
    boolean estado;
    int desgaste;
    boolean mensagemRodas;
    Suspensao suspensao;

    public Pneus(String tamanho, String tipo, double pressao, String marca, boolean estado, int desgaste, Suspensao suspensao) {
        this.tamanho = tamanho;
        this.tipo = tipo;
        this.pressao = pressao;
        this.marca = marca;
        this.estado = estado;
        this.desgaste = desgaste;
        this.suspensao = suspensao;
    }

    public boolean isMensagemRodas() {
        return mensagemRodas;
    }

    public void setMensagemRodas(boolean mensagemRodas) {
        this.mensagemRodas = mensagemRodas;
    }
    
    
    
    

    public int getDesgaste() {
        return desgaste;
    }

    public void setDesgaste(int desgaste) {
        this.desgaste = desgaste;
    }
    
    

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPressao() {
        return pressao;
    }

    public void setPressao(double pressao) {
        this.pressao = pressao;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    
    
    
    
    
public void verificarDesgaste () {
    int estadoAmortiguador = suspensao.getAmortiguador();
    
    
    if (estadoAmortiguador > 20 && this.desgaste > 10) {
        this.mensagemRodas = false;
        System.out.println("A roda está gastada, recomendado substituir");
        substituir();
        
    } else {
        this.mensagemRodas = true;
        System.out.println("Rodas em bom estado");
        
    }
        
    }
    
    
public void ajustarPressao (double novaPressao){
    System.out.println("Pressao de pneus ajustado");
    
}

public void substituir () {
    System.out.println("Pneu substituido");
    
}

public void desgastarPneu (){
    this.desgaste = this.desgaste + 1;
}

    
}
